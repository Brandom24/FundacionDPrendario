var exec = require('cordova/exec');

exports.initialize = function(userID, tanTanTkn, success, error) {
  exec(success, error, "FingersBidEnrollment", "initializeKaralundi", [userID,tanTanTkn]);
};

exports.initializeVerify = function(userID, tanTanTkn, success, error) {
  exec(success, error, "FingersBidEnrollment", "initializeKaralundiVerify", [userID,tanTanTkn]);
};

exports.initializeVerify4F = function(userID, tanTanTkn, success, error) {
  exec(success, error, "FingersBidEnrollment", "initializeKaralundiVerify4F", [userID,tanTanTkn]);
};

exports.initialize2F = function(userID, tanTanTkn, success, error) {
  exec(success, error, "FingersBidEnrollment", "initializeKaralundi2F", [userID,tanTanTkn]);
};

exports.enroll = function(jsonFPrints, success, error) {
  exec(success, error, "FingersBidEnrollment", "enrollKaralundi", [jsonFPrints]);
}